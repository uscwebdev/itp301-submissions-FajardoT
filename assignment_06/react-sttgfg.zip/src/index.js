import React from 'react';
import { createRoot } from 'react-dom/client';
import Product from './Product.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="header">
      <h2>Assignment 06: Shopping Cart</h2>
    </div>
    <h1>Time to Buy a Vinyl</h1>
    <div id="selection">
      <Product
        src="https://e-cdn-images.dzcdn.net/images/cover/00dd0da365a94b1829302d6b7fec70e6/256x256-000000-80-0-0.jpg"
        alt="To Pimp a Butterfly"
        title="To Pimp a Butterfly"
        price="25"
      />

      <Product
        src="https://c-cl.cdn.smule.com/rs-s-sf-1/arr/22/36/7ad59e2c-9148-4fda-9a54-8f7fd022f1a8.jpg"
        alt="YHLQMDLG"
        title="YHLQMDLG"
        price="15"
      />

      <Product
        src="https://e-cdn-images.dzcdn.net/images/cover/c9e44eae3791dd967caedc538696887b/256x256-000000-80-0-0.jpg"
        alt="La Vida Es Una"
        title="LA VIDA ES UNA"
        price="10"
      />

      <Product
        src="https://is2-ssl.mzstatic.com/image/thumb/Music112/v4/86/c9/bb/86c9bb30-fe3d-442e-33c1-c106c4d23705/17UMGIM88776.rgb.jpg/256x256bb.jpg"
        alt="DAMN"
        title="DAMN"
        price="20"
      />
    </div>
    <div id="footer">
      <h3>Created by Tony Fajardo</h3>
    </div>
  </React.StrictMode>
);
