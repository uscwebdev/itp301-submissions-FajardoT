import React from 'react';

export default function Product(prop) {
  return (
    <div>
      <img
        style={{
          borderRadius: '50%',
        }}
        src={prop.src}
        alt={prop.alt}
      />
      <h3>{prop.title}</h3>
      <p>Price: ${prop.price}</p>
    </div>
  );
}
