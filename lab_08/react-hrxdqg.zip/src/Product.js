import React from 'react';
import { useState } from 'react';

export default function Product() {
  // subtotal variable
  const [cost, setCost] = useState(0);

  // event handlers to add and subtract from subtotal with amount parameters
  function costUp(price) {
    price = parseInt(price);
    setCost(cost + price);
  }

  function costDown(price) {
    price = parseInt(price);
    setCost(cost - price);
  }

  return (
    <div>
      <div className="selection">
        <ProductOption
          src="https://e-cdn-images.dzcdn.net/images/cover/00dd0da365a94b1829302d6b7fec70e6/256x256-000000-80-0-0.jpg"
          alt="To Pimp a Butterfly"
          title="To Pimp a Butterfly"
          price="25"
          parentHandlerOne={costUp}
          parentHandlerTwo={costDown}
        />

        <ProductOption
          src="https://c-cl.cdn.smule.com/rs-s-sf-1/arr/22/36/7ad59e2c-9148-4fda-9a54-8f7fd022f1a8.jpg"
          alt="YHLQMDLG"
          title="YHLQMDLG"
          price="15"
          parentHandlerOne={costUp}
          parentHandlerTwo={costDown}
        />

        <ProductOption
          src="https://e-cdn-images.dzcdn.net/images/cover/c9e44eae3791dd967caedc538696887b/256x256-000000-80-0-0.jpg"
          alt="La Vida Es Una"
          title="LA VIDA ES UNA"
          price="10"
          parentHandlerOne={costUp}
          parentHandlerTwo={costDown}
        />

        <ProductOption
          src="https://is2-ssl.mzstatic.com/image/thumb/Music112/v4/86/c9/bb/86c9bb30-fe3d-442e-33c1-c106c4d23705/17UMGIM88776.rgb.jpg/256x256bb.jpg"
          alt="DAMN"
          title="DAMN"
          price="20"
          parentHandlerOne={costUp}
          parentHandlerTwo={costDown}
        />
      </div>

      <div id="cart">
        {/* displayed amount */}
        <p>Subtotal: ${cost}</p>
      </div>
    </div>
  );
}

function ProductOption(prop) {
  const [count, setCount] = useState(0);

  function increaseCount() {
    setCount(count + 1);
    prop.parentHandlerOne(prop.price);
  }

  function decreaseCount() {
    if (count > 0) {
      setCount(count - 1);
      prop.parentHandlerTwo(prop.price);
    }
  }

  return (
    <div>
      <div id="item">
        <img
          style={{
            borderRadius: '50%',
          }}
          src={prop.src}
          alt={prop.alt}
        />
        <h3>{prop.title}</h3>
        <p>Price: ${prop.price}</p>
      </div>
      <div className="cart">
        <button
          onClick={() => {
            decreaseCount();
          }}
        >
          -
        </button>
        <p>{count}</p>
        <button
          onClick={() => {
            increaseCount();
          }}
        >
          +
        </button>
      </div>
    </div>
  );
}
