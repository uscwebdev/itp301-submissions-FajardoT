import React from 'react';
import { createRoot } from 'react-dom/client';
import Product from './Product.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="header">
      <h2>Assignment 07: Shopping Cart w/ Item Count</h2>
    </div>
    <h1>Time to Buy a Vinyl</h1>
    <Product />
    <div id="footer">
      <h3>Created by Tony Fajardo</h3>
    </div>
  </React.StrictMode>
);
