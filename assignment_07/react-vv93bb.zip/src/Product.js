import React from 'react';
import { useState } from 'react';

export default function Product(prop) {
  const [count, setCount] = useState(0);

  function increaseCount() {
    setCount(count + 1);
  }

  function decreaseCount() {
    if (count > 0) {
      setCount(count - 1);
    }
  }

  return (
    <div>
      <div id="item">
        <img
          style={{
            borderRadius: '50%',
          }}
          src={prop.src}
          alt={prop.alt}
        />
        <h3>{prop.title}</h3>
        <p>Price: ${prop.price}</p>
      </div>
      <div class="cart">
        <button onClick={decreaseCount}>-</button>
        <p>{count}</p>
        <button onClick={increaseCount}>+</button>
      </div>
    </div>
  );
}
