import React from 'react';
import { createRoot } from 'react-dom/client';
import Comment from './Comment.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>My Static Page for Music Reviews</h1>
    <p>
      I tend to listen to music as often as I can. It's a good way to pass the
      time for me. I tend to also listen to other genres from my childhood.
    </p>
    <p>Here are some are my favorite songs from the past and present.</p>
    <p>Let me know what you think about them and leave and recs.</p>

    <div id="music">
      <div className="song">
        <img
          src="https://c-cl.cdn.smule.com/rs-s80/arr/83/bc/15af3d60-b96d-4a40-8a17-af29c9c235a5.jpg"
          alt="dime si te gusto - aventura"
        />
        <a href="https://youtu.be/rSsKNgcKlAs?si=0Cyx__AU6INai5am">
          Aventura - Dime Si Te Gusto
        </a>
      </div>

      <div className="song">
        <img
          src="https://photo-resize-zmp3.zmdcdn.me/w256_r1x1_jpeg/cover/b/9/d/a/b9da4d8a570bb308229adaa501323f9a.jpg"
          alt="MOJABI GHOST - Tainy, Bad Bunny"
        />
        <a href="https://www.youtube.com/watch?v=O1wUdB7MQbI&ab_channel=Tainy">
          MOJABI GHOST - Tainy, Bad Bunny
        </a>
      </div>

      <div className="song">
        <img
          src="https://e-cdn-images.dzcdn.net/images/cover/916d3aa36acc0347100e37b3d65f24a4/256x256-000000-80-0-0.jpg"
          alt="La Vida Es Un Carnaval - Celia Cruz          "
        />
        <a href="https://www.youtube.com/watch?v=0nBFWzpWXuM&ab_channel=09SourApple">
          La Vida Es Un Carnaval - Celia Cruz
        </a>
      </div>
    </div>

    <div id="comments">
      <Comment
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBzDd-OzeRpSe3i9iWhHOv2hKnPWH3U1E5S4liz6NT56cSsSMulCXOwXt0k47O56IEV1c&usqp=CAU"
        alt="frog on skateboard"
        name="@potatorun"
        text="I enjoy these songs too. I am waiting to see what Romeo will release
      in the future!"
        date="3.5.2023"
      />
      <Comment
        src="https://cdn-icons-png.flaticon.com/256/7603/7603322.png"
        alt="cartoon panda waving hello"
        name="@moviesonthego"
        text="Celia is definitely one of my mother's faviotre artists. I remember
      growing up listening to her music as well."
        date="5.3.2023"
      />
      <Comment
        src="https://kudos.tv/cdn/shop/files/Baby_Nissan_300x.gif?v=1679069333"
        alt="gif of a car on a highway at night"
        name="@boxingring"
        text="Definitely love bachata for all the memories I have listening to it
      with my family. Hopefully people continue to listen and share the
      music with others."
        date="3.12.2023"
      />
      <Comment
        src="https://i0.wp.com/www.followchain.org/wp-content/uploads/2021/09/best-discord-profile-pictures-9.png?resize=256%2C256&ssl=1"
        alt="dog with a pancake in its mouth with a space backdrop"
        name="@hiddengems"
        text="I tend to like the new generation of music but I will definitely be
      checking out more genres from now on."
        date="4.12.2023"
      />
      {/* <div className="post">
        <img
          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBzDd-OzeRpSe3i9iWhHOv2hKnPWH3U1E5S4liz6NT56cSsSMulCXOwXt0k47O56IEV1c&usqp=CAU"
          alt="frog on skateboard"
        />
        <div className="content">
          <strong>@potatorun</strong>
          <p>
            I enjoy these songs too. I am waiting to see what Romeo will release
            in the future!
          </p>
          <p className="date"> Posted: 3.5.2023</p>
        </div>
      </div>

      <div className="post">
        <img
          src="https://cdn-icons-png.flaticon.com/256/7603/7603322.png"
          alt="cartoon panda waving hello"
        />
        <div className="content">
          <strong>@moviesonthego</strong>
          <p>
            Celia is definitely one of my mother's faviotre artists. I remember
            growing up listening to her music as well.
          </p>
          <p className="date"> Posted: 5.3.2023</p>
        </div>
      </div>

      <div className="post">
        <img
          src="https://kudos.tv/cdn/shop/files/Baby_Nissan_300x.gif?v=1679069333"
          alt="gif of a car on a highway at night"
        />
        <div className="content">
          <strong>@boxingring</strong>
          <p>
            Definitely love bachata for all the memories I have listening to it
            with my family. Hopefully people continue to listen and share the
            music with others.
          </p>
          <p className="date"> Posted: 3.12.2023</p>
        </div>
      </div>

      <div className="post">
        <img
          src="https://i0.wp.com/www.followchain.org/wp-content/uploads/2021/09/best-discord-profile-pictures-9.png?resize=256%2C256&ssl=1"
          alt="dog with a pancake in its mouth with a space backdrop"
        />
        <div className="content">
          <strong>@hiddengems</strong>
          <p>
            I tend to like the new generation of music but I will definitely be
            checking out more genres from now on.
          </p>
          <p className="date"> Posted: 4.12.2023</p>
        </div>
      </div> */}
    </div>
  </React.StrictMode>
);
