import React from 'react';

export default function Comment(prop) {
  return (
    <div>
      <div className="post">
        <img src={prop.src} alt={prop.alt} />
        <div className="content">
          <strong>{prop.name}</strong>
          <p>{prop.text}</p>
          <p className="date"> Posted: {prop.date}</p>
        </div>
      </div>
    </div>
  );
}
