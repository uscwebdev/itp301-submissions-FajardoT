import React from 'react';
import { useState } from 'react';

export default function ImageChange(prop) {
  const [src, setSrc] = useState(
    'https://images.vexels.com/media/users/3/229548/isolated/lists/87a42655e843df4b08d8f036eda45ebb-american-football-side-illustration.png'
  );

  const [alt, setAlt] = useState('Football');

  const [caption, setCaption] = useState('Football');

  function changeImage(newSrc, newAlt, newCaption) {
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCaption);
  }

  return (
    <div>
      <div id="buttons">
        {/* football image */}
        <button
          onClick={() => {
            changeImage(
              'https://images.vexels.com/media/users/3/229548/isolated/lists/87a42655e843df4b08d8f036eda45ebb-american-football-side-illustration.png',
              'Football',
              'Football'
            );
          }}
        >
          Image 1
        </button>

        {/* soccer image */}
        <button
          onClick={() => {
            changeImage(
              'https://icons.iconarchive.com/icons/yingfengling-fl/i-love-sports/256/soccer-icon.png',
              'Soccer',
              'Soccer'
            );
          }}
        >
          Image 2
        </button>

        {/* basketball image */}
        <button
          onClick={() => {
            changeImage(
              'https://is1-ssl.mzstatic.com/image/thumb/Purple126/v4/4c/00/01/4c0001f4-2918-01f1-6ae7-c9b981c4459c/AppIcon-0-0-1x_U007emarketing-0-0-0-7-0-0-sRGB-0-0-0-GLES2_U002c0-512MB-85-220-0-0.png/256x256bb.jpg',
              'Basketball',
              'Basketball'
            );
          }}
        >
          Image 3
        </button>

        {/* tennis image */}
        <button
          onClick={() => {
            changeImage(
              'https://images-stylist.s3-eu-west-1.amazonaws.com/app/uploads/2023/06/20113149/tennis-mental-agility-256x256.jpg',
              'Tennis',
              'Tennis'
            );
          }}
        >
          Image 4
        </button>

        {/* boxing image */}
        <button
          onClick={() => {
            changeImage(
              'https://davisphinneyfoundation.org/wp-content/uploads/2021/05/latestgreatestboxing900x600-256x256.png',
              'Boxing',
              'Boxing'
            );
          }}
        >
          Image 5
        </button>

        {/* baseball image */}
        <button
          onClick={() => {
            changeImage(
              'https://www.iscream-shop.com/web/image/product.template/964/image_256',
              'Baseball',
              'Baseball'
            );
          }}
        >
          Image 6
        </button>
      </div>

      {/* main photo */}

      <img id="display" src={src} alt={alt} />
      <p>{caption}</p>
    </div>
  );
}
