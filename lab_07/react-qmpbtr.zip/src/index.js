import React from 'react';
import { createRoot } from 'react-dom/client';
import ImageChange from './ImageChange.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>A Selection of My Favorite Sports</h1>
    <ImageChange />
  </React.StrictMode>
);
