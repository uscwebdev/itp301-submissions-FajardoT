import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import { Link } from 'react-router-dom';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>Tony Fajardo</h1>
    <a href="tfajardo@usc.edu">tfajardo@usc.edu</a>
    <p id="favorite">Golden Rod</p>
    <p>
      Favorite Wehbsite: <a href="youtube.com">Youtube</a>
    </p>
    <img
      class="activity"
      src="https://static.independent.co.uk/s3fs-public/thumbnails/image/2017/11/08/10/istock-502324324.jpg"
      alt="Listening to Music"
    />
    <h2>Fall 2023 Courses</h2>
    <ul>
      <li>JOUR 464</li>
      <li>ITP 301</li>
      <li>ITP 310</li>
      <li>JOUR 461</li>
      <li>JOUR 462</li>
    </ul>
  </React.StrictMode>
);
