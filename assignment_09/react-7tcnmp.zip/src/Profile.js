import React from 'react';

export default function Profile(item) {
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        margin: 'auto',
        backgroundColor: 'goldenrod',
        borderRadius: '5%',
      }}
    >
      <div
        style={{
          width: '30%',
          textAlign: 'center',
        }}
      >
        <img
          style={{
            borderRadius: '30%',
          }}
          src={item.src}
          alt={item.alt}
        />
      </div>

      <div>
        <h1>{item.name}</h1>
        <p>{item.bio}</p>
      </div>
    </div>
  );
}
