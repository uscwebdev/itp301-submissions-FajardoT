import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Profile from './Profile.js';
import Hits from './Hits.js';
import Playlist from './Playlist.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="header">
      <h1>Discodeck</h1>
      <h3>An insight into a different musical world.</h3>
    </div>

    <div>
      <h3>Menu</h3>
      <p>Artists Biographies</p>
      <p>Beginner 5 Songs</p>
      <p>Mood Playlists</p>
    </div>

    <div className="body">
      <div className="artists">
        <Profile
          src="https://api.mapsound.ar/StaticFiles/48abe7e0-36e5-435a-b49a-db85b0368b26.jpg"
          alt="Eladio Carrion"
          name="Eladio Carrion"
          bio="Eladio Carrion has demosntrated to be one of the mainstays of the latin trap genre with his consistency of music. Typically you see many artists dive into other genres that might be considered more mainstream but Eladio has been able to maintain a loyal fanbase over the years. Although some might believe this could limit the reach you could get to, it's clear that he's been able to grow within the genre and shows no signs of slowing down."
        />
        <Profile
          src="https://photo-resize-zmp3.zmdcdn.me/w256_r1x1_jpeg/cover/d/7/4/9/d749c88cb781745be1050819a16d128d.jpg"
          alt="Dei V"
          name="Dei V"
          bio="Dei V has recently been on the rise and is being considered as one of the leaders of the new generation of artists coming out of Puerto Rico. With co-signs from artists like Bad Bunny and collaborations with major artists such as Karol G, Dei V is showing no signs of slowing down anytime soon. With songs like 'VVS' and 'Quien Es Dei V?', Dei V demonstrates he'll be able to adapt to new waves of music that come around in the upcoming years."
        />
        <Profile
          src="https://socialcounts.org/_next/image?url=https%3A%2F%2Fwww.banner.yt%2FUCcsuP-RU90LNZBluSJNJXiQ%2Favatar%3Fwidth%3D640&w=256&q=75"
          alt="Young Miko"
          name="Young Miko"
          bio="I haven't seen an artists blow up as much as Young Miko has in the past year and a half. Starting off with smaller shows in Puerto Rico, she's recently coming off a tour in Latin America with consistent music coming out during the months on the road. She's been seen as one of the faces for women in the urban music scene the LGBTQ+ community has also put her in the hearts of fans in a genre that has been seen as place full of toxic masculinity."
        />
        <Profile
          src="https://firebase.soulectiontracklists.com/cdn/image/t_square_large/images/artists/bad-bunny.jpg"
          alt="Bad Bunny"
          name="Bad Bunny"
          bio="Bad Bunny needs little to no introduction to the global stage, much less to the Latin trap scene. However, it is important to note the early stages of his career where he would be considered the face of genre and an inspiration for those that wanted to elevate the genre to a larger stage. Although he doesn't dive much into the genre anymore, his recent album had him show off his ability to collab with the fresh faces of Latin Trap and fulfilling the wishes of many of his fans who had been there from the start."
        />
      </div>
      <div>
        <h1>Artists' Hits to Check Out First</h1>
        <p>
          Check out some of the artists' top hits that will give you an idea of
          their style and flow. Although just a snippet of their talent, I
          believe these songs are able to capture their essence in the Latin
          Trap genre.
        </p>
      </div>
      <div className="hits">
        <Hits
          name="Eladio Carrion's Hits"
          srcone="https://c-cl.cdn.smule.com/smule-gg-uw1-s-7/arr/c8/4a/0c8a5e86-dcfc-4c65-bf98-abd0db42bd3d.jpg"
          altone="Coco Chanel"
          titleone="Coco Chanel"
          srctwo="https://i1.sndcdn.com/artworks-jwtUrh33VBy7zktU-gWlNXQ-t500x500.jpg"
          alttwo="Jovenes Millionarios"
          titletwo="Jovenes Millionarios"
          srcthree="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/ed/0e/75/ed0e75e3-9076-be3d-7744-b5e17b256e7f/196292648966.jpg/1200x1200bf-60.jpg"
          altthree="Sauce Boy Freestlye 5"
          titlethree="Sauce Boy Freestyle 5"
          srcfour="https://i.scdn.co/image/ab67616d0000b27370030b2894d44b3fb2a53ed8"
          altfour="Eladio Carrion: Bzrp Music Sessions, Vol. 40"
          titlefour="Eladio Carrion: Bzrp Music Sessions, Vol. 40"
          srcfive="https://images.genius.com/a61f4ac97238a47c6fa8724b58a09ffc.1000x1000x1.png"
          altfive="Kemba Walker"
          titlefive="Kemba Walker"
          bio="Both old and new fans of Eladio are able to see the various styles he's been able to dive into witin the Latin Trap genre. Whether they are songs that tend to fit the 'image' trap has generated for itself in the past, he's also been able to release many sentimental songs talking about his own struggles that many have resonated with."
        />
        <Hits
          name="Dei V's Hits"
          srcone="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/02/a1/55/02a155ad-5518-fb16-bd80-fd2f9c392a94/0.jpg/1200x1200bf-60.jpg"
          altone="Matricula"
          titleone="Matricula"
          srctwo="https://m.media-amazon.com/images/I/31HYQD0rZfL._UXNaN_FMjpg_QL85_.jpg"
          alttwo="CRUSH"
          titletwo="CRUSH"
          srcthree="https://m.media-amazon.com/images/I/61buvE6THeL._UXNaN_FMjpg_QL85_.jpg"
          altthree="en guerra"
          titlethree="en guerra"
          srcfour="https://m.media-amazon.com/images/I/51BrO+fiJ2L._UXNaN_FMjpg_QL85_.jpg"
          altfour="Quien Es Dei V?"
          titlefour="Quien Es Dei V?"
          srcfive="https://m.media-amazon.com/images/I/515NWxqPNNL._UXNaN_FMjpg_QL85_.jpg"
          altfive="Trending"
          titlefive="Trending"
          bio="Dei V has been very open with changing up the type of music he offers his fans. He's able to give a lot for his fans that are used to his music 'for the streets' but he's also provided music that's able to be played at nightclubs. Overall, Dei V has shown off his versatility which is something that many aren't able to pull off when they need to."
        />

        <Hits
          name="Young Miko's Hits"
          srcone="https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/ab/63/6a/ab636a6c-3624-7536-245a-ed863f36806e/artwork.jpg/1200x1200bb.jpg"
          altone="105 Freestyle"
          titleone="105 Frreestyle"
          srctwo="https://i.scdn.co/image/ab67616d0000b27351fe68b32d3fcd0e49afee76"
          alttwo="Standard"
          titletwo="Standard"
          srcthree="https://i.scdn.co/image/ab67616d0000b27348b74b66dab23f60aa6ff3af"
          altthree="Riri"
          titlethree="Riri"
          srcfour="https://i.scdn.co/image/ab67616d0000b2731fcf8dc413896f0fb5749141"
          altfour="Lisa"
          titlefour="Lisa"
          srcfive="https://i1.sndcdn.com/artworks-7SQF5kUYKJPSOEYD-Yv6ECA-t500x500.jpg"
          altfive="La Mini"
          titlefive="La Mini"
          bio="Young Miko's Spanglish is a notable part of her rhyming and flow for her songs. Whether she says simply states a few words or entire phrases in English, she's able to make it work for her songs. Additionally, she's dived into genres like reggaeton and collabed with artists like Feid and Karol G to provide classics in addition to those she's provided on singles."
        />

        <Hits
          name="Bad Bunny's Hits"
          srcone="https://i.scdn.co/image/ab67616d0000b273147689b8550e68c0e6f78411"
          altone="Chambea"
          titleone="Chambea"
          srctwo="https://i.scdn.co/image/ab67616d0000b273f68d3148a46b457e05f2acde"
          alttwo="Amorfoda"
          titletwo="Amorfoda"
          srcthree="https://i.scdn.co/image/ab67616d0000b273955c3c2ac8d97e1355b2e3c2"
          altthree="Soy Peor"
          titlethree="Soy Peor"
          srcfour="https://i.scdn.co/image/ab67616d0000b2732fbd77033247e889cb7d2ac4"
          altfour="Otra Noche en Miami"
          titlefour="Otra Noche en Miami"
          srcfive="https://i.scdn.co/image/ab67616d0000b2737b1fc51ff3257b5286a1ecec"
          altfive="MONACO"
          titlefive="MONACO"
          bio="Bad Bunny's music has evolved over the years from sticking only to trap music to even starting to experiement with new sounds on some of his latest singles such as Jersey Club music. However, Bad Bunny's versatility is shown greatly in his Trap catalogue with songs that are able to evoke all types of emotions from excitement to sadness."
        />
      </div>
      <div>
        <h1>Mood Playlists</h1>
        <p>
          Enjoy some songs from some of the artists based on what mood you want
          to experiment with.
        </p>
      </div>
      <div className="playlists">
        <Playlist
          title="Eladio's Playlist for the Gym"
          one="THUNDER Y LIGHTNING"
          two="Mbappe"
          three="Si La Calle Llama - Remix"
          four="Si Salimos"
          five="Tata - Remix"
          six="Nube"
          seven="Eladio Carrion: Bzrp Music Sessions, Vol. 40"
          eight="5 Star"
          nine="Problema"
          ten="Jovenes Millonarios"
          eleven="Como Sea"
          twelve="Socio"
          thirteen="Mami Dijo"
          fourteen="Sauce Boy Freesyle 3"
          fifteen="Hugo"
        />

        <Playlist
          title="Young Miko's Party Playlist"
          one="Classy 101"
          two="Chulo pt.2"
          three="wiggy"
          four="DISPO"
          five="ID"
          six="105 Freestyle"
          seven="Vendetta"
          eight="Puerto Rican Mami"
          nine="2seater"
          ten="Bi"
          eleven="Riri"
          twelve="Trending"
          thirteen="Lisa"
          fourteen="Katana"
          fifteen="Kilimanjaro"
        />
        <Playlist
          title="Sad Bunny's Late Night Playlist"
          one="NI BIEN NI MAL"
          two="Amorfoda"
          three="RLNDT"
          four="Un Verano Sin Ti"
          five="Soy Peor"
          six="LA DROGA"
          seven="HACIENDO QUE ME AMAS"
          eight="BABY NUEVA"
          nine="Dime Si Te Acuerdas"
          ten="Solo de Mi"
          eleven="Otra Noche en Miami"
          twelve="LA CANCIÓN"
          thirteen="Dos Mil 16"
          fourteen="Vete"
          fifteen="GRACIAS POR NADA"
        />
      </div>
    </div>
  </React.StrictMode>
);
